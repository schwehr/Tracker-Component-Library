This is a python implementation of the geodesic routines from
GeographicLib.  This contains implementations of the classes

- GeographicLib::Math
- GeographicLib::Accumulator
- GeographicLib::Geodesic
- GeographicLib::GeodesicLine
- GeographicLib::PolygonArea

For more information on GeographicLib, see

  http://geographiclib.sf.net
